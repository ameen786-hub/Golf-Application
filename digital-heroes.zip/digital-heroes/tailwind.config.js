/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#0B1410",       // near-black forest ink, main background
        pine: "#122019",      // panel background
        moss: "#1B3227",      // border / hairline
        parchment: "#F3EFE4", // primary text on dark
        ember: "#E08A3E",     // prize / CTA accent (warm amber-orange)
        clover: "#6FAE8C",    // charity / giving accent (soft green)
        rose: "#D97A66",      // winner / highlight accent
        mute: "#9AA79E",      // secondary text
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};
