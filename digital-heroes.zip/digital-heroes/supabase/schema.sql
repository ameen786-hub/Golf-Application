-- ============================================================================
-- Digital Heroes — database schema
-- Run this once in a NEW Supabase project (SQL Editor -> New query -> Run)
-- ============================================================================

-- 1. PROFILES ----------------------------------------------------------------
-- Extends auth.users. Created automatically by the trigger below on signup.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'subscriber' check (role in ('subscriber', 'admin')),
  charity_id uuid references public.charities(id),
  charity_percentage numeric not null default 10 check (charity_percentage >= 10 and charity_percentage <= 100),
  created_at timestamptz not null default now()
);

-- 2. CHARITIES ----------------------------------------------------------------
create table if not exists public.charities (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  image_url text,
  events jsonb not null default '[]'::jsonb, -- [{title, date, location}]
  featured boolean not null default false,
  created_at timestamptz not null default now()
);

-- profiles.charity_id references charities, so add the FK now that both exist.
alter table public.profiles
  drop constraint if exists profiles_charity_id_fkey;
alter table public.profiles
  add constraint profiles_charity_id_fkey foreign key (charity_id) references public.charities(id);

-- 3. SUBSCRIPTIONS --------------------------------------------------------------
create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan text not null check (plan in ('monthly', 'yearly')),
  status text not null default 'inactive' check (status in ('active', 'inactive', 'canceled', 'lapsed')),
  stripe_customer_id text,
  stripe_subscription_id text,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_subscriptions_user on public.subscriptions(user_id);

-- 4. SCORES (Stableford, rolling last 5) ----------------------------------------
create table if not exists public.scores (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  score int not null check (score >= 1 and score <= 45),
  played_on date not null,
  created_at timestamptz not null default now(),
  unique (user_id, played_on) -- one entry per date
);
create index if not exists idx_scores_user on public.scores(user_id, played_on desc);

-- Enforce "only the latest 5 scores are retained": a trigger deletes the
-- oldest row once a user has more than 5 entries.
create or replace function public.trim_scores_to_five()
returns trigger as $$
begin
  delete from public.scores
  where id in (
    select id from public.scores
    where user_id = new.user_id
    order by played_on desc
    offset 5
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists trg_trim_scores on public.scores;
create trigger trg_trim_scores
  after insert on public.scores
  for each row execute function public.trim_scores_to_five();

-- 5. DRAWS -----------------------------------------------------------------
create table if not exists public.draws (
  id uuid primary key default gen_random_uuid(),
  draw_month date not null unique, -- first day of the month this draw covers
  draw_type text not null default 'random' check (draw_type in ('random', 'algorithmic')),
  status text not null default 'draft' check (status in ('draft', 'simulated', 'published')),
  winning_numbers int[] not null default '{}',
  active_subscribers int not null default 0,
  pool_total numeric not null default 0,
  tier5_pool numeric not null default 0,
  tier4_pool numeric not null default 0,
  tier3_pool numeric not null default 0,
  jackpot_rollover numeric not null default 0,
  created_at timestamptz not null default now(),
  published_at timestamptz
);

-- 6. TICKETS ------------------------------------------------------------------
-- Every active subscriber gets one ticket (5 numbers) per draw. For the
-- "algorithmic" draw type, numbers are weighted by the user's recent score
-- frequency (see lib/draw.ts); for "random" they are uniformly random.
create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  draw_id uuid not null references public.draws(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  numbers int[] not null,
  created_at timestamptz not null default now(),
  unique (draw_id, user_id)
);

-- 7. WINNERS ------------------------------------------------------------------
create table if not exists public.winners (
  id uuid primary key default gen_random_uuid(),
  draw_id uuid not null references public.draws(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  tier int not null check (tier in (3, 4, 5)),
  amount numeric not null default 0,
  proof_url text,
  verification_status text not null default 'pending' check (verification_status in ('pending', 'approved', 'rejected')),
  payment_status text not null default 'pending' check (payment_status in ('pending', 'paid')),
  reviewed_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index if not exists idx_winners_user on public.winners(user_id);

-- ============================================================================
-- Auto-create a profile row whenever a new auth user signs up.
-- ============================================================================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''));
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================================
-- Row Level Security
-- ============================================================================
alter table public.profiles enable row level security;
alter table public.charities enable row level security;
alter table public.subscriptions enable row level security;
alter table public.scores enable row level security;
alter table public.draws enable row level security;
alter table public.tickets enable row level security;
alter table public.winners enable row level security;

-- Helper: is the current user an admin?
create or replace function public.is_admin()
returns boolean as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$ language sql security definer stable;

-- Profiles: users read/update their own row; admins read/update all.
create policy "profiles_select_own_or_admin" on public.profiles
  for select using (id = auth.uid() or public.is_admin());
create policy "profiles_update_own_or_admin" on public.profiles
  for update using (id = auth.uid() or public.is_admin());

-- Charities: public read, admin write.
create policy "charities_select_all" on public.charities for select using (true);
create policy "charities_admin_write" on public.charities for all using (public.is_admin()) with check (public.is_admin());

-- Subscriptions: owner + admin read; only admin/service role writes directly
-- (normal writes happen via the Stripe webhook using the service role key).
create policy "subscriptions_select_own_or_admin" on public.subscriptions
  for select using (user_id = auth.uid() or public.is_admin());
create policy "subscriptions_admin_write" on public.subscriptions
  for all using (public.is_admin()) with check (public.is_admin());

-- Scores: owner manages their own; admin can manage all.
create policy "scores_select_own_or_admin" on public.scores
  for select using (user_id = auth.uid() or public.is_admin());
create policy "scores_insert_own" on public.scores
  for insert with check (user_id = auth.uid() or public.is_admin());
create policy "scores_update_own_or_admin" on public.scores
  for update using (user_id = auth.uid() or public.is_admin());
create policy "scores_delete_own_or_admin" on public.scores
  for delete using (user_id = auth.uid() or public.is_admin());

-- Draws: any authenticated user can read published draws; admin sees/edits all.
create policy "draws_select_published_or_admin" on public.draws
  for select using (status = 'published' or public.is_admin());
create policy "draws_admin_write" on public.draws
  for all using (public.is_admin()) with check (public.is_admin());

-- Tickets: owner + admin read only; written by admin/service role during draw run.
create policy "tickets_select_own_or_admin" on public.tickets
  for select using (user_id = auth.uid() or public.is_admin());
create policy "tickets_admin_write" on public.tickets
  for all using (public.is_admin()) with check (public.is_admin());

-- Winners: owner + admin read; owner can upload proof (update proof_url only
-- via the app layer); admin verifies/pays.
create policy "winners_select_own_or_admin" on public.winners
  for select using (user_id = auth.uid() or public.is_admin());
create policy "winners_update_own_proof_or_admin" on public.winners
  for update using (user_id = auth.uid() or public.is_admin());
create policy "winners_admin_write" on public.winners
  for all using (public.is_admin()) with check (public.is_admin());

-- ============================================================================
-- Storage bucket for winner proof screenshots
-- ============================================================================
insert into storage.buckets (id, name, public)
values ('winner-proofs', 'winner-proofs', false)
on conflict (id) do nothing;

create policy "winner_proofs_owner_upload" on storage.objects
  for insert with check (
    bucket_id = 'winner-proofs' and auth.uid()::text = (storage.foldername(name))[1]
  );
create policy "winner_proofs_owner_or_admin_read" on storage.objects
  for select using (
    bucket_id = 'winner-proofs' and (
      auth.uid()::text = (storage.foldername(name))[1] or public.is_admin()
    )
  );

-- ============================================================================
-- Seed: make the first signed-up admin manually with, e.g.
--   update public.profiles set role = 'admin' where id = '<your-user-uuid>';
-- ============================================================================
