"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function ProofUpload({
  winnerId,
  userId,
  existingUrl,
}: {
  winnerId: string;
  userId: string;
  existingUrl: string | null;
}) {
  const supabase = createClient();
  const router = useRouter();
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);

    const path = `${userId}/${winnerId}-${Date.now()}.${file.name.split(".").pop()}`;
    const { error: uploadError } = await supabase.storage
      .from("winner-proofs")
      .upload(path, file, { upsert: true });

    if (uploadError) {
      setUploading(false);
      setError(uploadError.message);
      return;
    }

    const { error: updateError } = await supabase
      .from("winners")
      .update({ proof_url: path, verification_status: "pending" })
      .eq("id", winnerId);

    setUploading(false);
    if (updateError) return setError(updateError.message);
    router.refresh();
  }

  return (
    <div className="text-sm">
      {existingUrl ? (
        <p className="text-clover">Proof submitted — awaiting review.</p>
      ) : (
        <label className="inline-block cursor-pointer text-ink bg-ember px-4 py-1.5 rounded-full font-medium hover:brightness-110 transition">
          {uploading ? "Uploading…" : "Upload proof"}
          <input type="file" accept="image/*" className="hidden" onChange={handleFile} />
        </label>
      )}
      {error && <p className="text-rose mt-1">{error}</p>}
    </div>
  );
}
