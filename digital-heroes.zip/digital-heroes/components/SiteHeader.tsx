import Link from "next/link";

export default function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-ink/80 border-b hairline">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link href="/" className="font-display text-xl tracking-tight">
          Digital Heroes
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-mute">
          <Link href="/#how-it-works" className="hover:text-parchment transition-colors">
            How it works
          </Link>
          <Link href="/charities" className="hover:text-parchment transition-colors">
            Charities
          </Link>
          <Link href="/#prizes" className="hover:text-parchment transition-colors">
            Prizes
          </Link>
        </nav>
        <div className="flex items-center gap-3">
          <Link
            href="/login"
            className="text-sm text-parchment hover:text-ember transition-colors"
          >
            Sign in
          </Link>
          <Link
            href="/signup"
            className="text-sm font-medium bg-ember text-ink px-4 py-2 rounded-full hover:brightness-110 transition"
          >
            Subscribe
          </Link>
        </div>
      </div>
    </header>
  );
}
