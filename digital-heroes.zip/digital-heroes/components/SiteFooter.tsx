import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer className="border-t hairline mt-24">
      <div className="max-w-6xl mx-auto px-6 py-12 flex flex-col md:flex-row justify-between gap-8">
        <div>
          <p className="font-display text-lg">Digital Heroes</p>
          <p className="text-sm text-mute mt-2 max-w-xs">
            Every round you play helps fund a cause you believe in. Prizes are
            a bonus — the giving is the point.
          </p>
        </div>
        <div className="flex gap-16 text-sm">
          <div className="flex flex-col gap-2">
            <span className="text-parchment mb-1">Platform</span>
            <Link href="/#how-it-works" className="text-mute hover:text-parchment">
              How it works
            </Link>
            <Link href="/charities" className="text-mute hover:text-parchment">
              Charities
            </Link>
            <Link href="/signup" className="text-mute hover:text-parchment">
              Subscribe
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <span className="text-parchment mb-1">Account</span>
            <Link href="/login" className="text-mute hover:text-parchment">
              Sign in
            </Link>
            <Link href="/dashboard" className="text-mute hover:text-parchment">
              Dashboard
            </Link>
          </div>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-6 pb-8 text-xs text-mute">
        Digital Heroes is a sample platform built for a development
        selection process. Not a real gambling or charity product.
      </div>
    </footer>
  );
}
