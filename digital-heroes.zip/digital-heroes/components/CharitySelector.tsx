"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type Charity = { id: string; name: string };

export default function CharitySelector({
  userId,
  charities,
  currentCharityId,
  currentPercentage,
}: {
  userId: string;
  charities: Charity[];
  currentCharityId: string | null;
  currentPercentage: number;
}) {
  const supabase = createClient();
  const router = useRouter();
  const [charityId, setCharityId] = useState(currentCharityId ?? "");
  const [percentage, setPercentage] = useState(currentPercentage);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    setSaving(true);
    setSaved(false);
    await supabase
      .from("profiles")
      .update({ charity_id: charityId || null, charity_percentage: percentage })
      .eq("id", userId);
    setSaving(false);
    setSaved(true);
    router.refresh();
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <label className="text-xs text-mute block mb-1">Charity</label>
        <select
          value={charityId}
          onChange={(e) => setCharityId(e.target.value)}
          className="w-full bg-ink border hairline rounded-lg px-3 py-2 outline-none focus:border-ember text-sm"
        >
          <option value="">Choose a charity…</option>
          {charities.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="text-xs text-mute block mb-1">
          Contribution — {percentage}% of your subscription
        </label>
        <input
          type="range"
          min={10}
          max={100}
          step={5}
          value={percentage}
          onChange={(e) => setPercentage(Number(e.target.value))}
          className="w-full accent-clover"
        />
        <p className="text-xs text-mute mt-1">Minimum contribution is 10%.</p>
      </div>
      <button
        onClick={handleSave}
        disabled={saving || !charityId}
        className="self-start bg-clover text-ink text-sm font-medium px-5 py-2 rounded-full hover:brightness-110 transition disabled:opacity-50"
      >
        {saving ? "Saving…" : "Save charity"}
      </button>
      {saved && <p className="text-xs text-clover">Saved.</p>}
    </div>
  );
}
