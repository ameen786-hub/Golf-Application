"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type Score = { id: string; score: number; played_on: string };

export default function ScoreEntryForm({
  userId,
  scores,
}: {
  userId: string;
  scores: Score[];
}) {
  const supabase = createClient();
  const router = useRouter();
  const [score, setScore] = useState("");
  const [playedOn, setPlayedOn] = useState(() => new Date().toISOString().slice(0, 10));
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const value = Number(score);
    if (!Number.isInteger(value) || value < 1 || value > 45) {
      setError("Score must be a whole number between 1 and 45 (Stableford).");
      return;
    }

    setLoading(true);

    if (editingId) {
      const { error } = await supabase
        .from("scores")
        .update({ score: value, played_on: playedOn })
        .eq("id", editingId);
      setLoading(false);
      if (error) return setError(error.message);
    } else {
      const { error } = await supabase
        .from("scores")
        .upsert(
          { user_id: userId, score: value, played_on: playedOn },
          { onConflict: "user_id,played_on" }
        );
      setLoading(false);
      if (error) return setError(error.message);
    }

    setScore("");
    setEditingId(null);
    router.refresh();
  }

  async function handleDelete(id: string) {
    await supabase.from("scores").delete().eq("id", id);
    router.refresh();
  }

  function startEdit(s: Score) {
    setEditingId(s.id);
    setScore(String(s.score));
    setPlayedOn(s.played_on);
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="flex flex-wrap items-end gap-3 mb-6">
        <div>
          <label className="text-xs text-mute block mb-1">Date played</label>
          <input
            type="date"
            required
            value={playedOn}
            onChange={(e) => setPlayedOn(e.target.value)}
            className="bg-ink border hairline rounded-lg px-3 py-2 outline-none focus:border-ember text-sm"
          />
        </div>
        <div>
          <label className="text-xs text-mute block mb-1">Stableford score</label>
          <input
            type="number"
            min={1}
            max={45}
            required
            value={score}
            onChange={(e) => setScore(e.target.value)}
            className="bg-ink border hairline rounded-lg px-3 py-2 outline-none focus:border-ember w-28 text-sm"
          />
        </div>
        <button
          disabled={loading}
          className="bg-ember text-ink text-sm font-medium px-5 py-2 rounded-full hover:brightness-110 transition disabled:opacity-50"
        >
          {editingId ? "Save changes" : "Add score"}
        </button>
        {editingId && (
          <button
            type="button"
            onClick={() => {
              setEditingId(null);
              setScore("");
            }}
            className="text-mute text-sm hover:text-parchment"
          >
            Cancel
          </button>
        )}
      </form>

      {error && <p className="text-rose text-sm mb-4">{error}</p>}

      <div className="border hairline rounded-xl2 divide-y divide-moss overflow-hidden">
        {scores.length === 0 && (
          <p className="px-5 py-6 text-mute text-sm">
            No rounds logged yet. Add your first score above to enter the
            draw.
          </p>
        )}
        {scores.map((s) => (
          <div key={s.id} className="flex items-center justify-between px-5 py-3">
            <div>
              <p className="font-medium">{s.score} points</p>
              <p className="text-xs text-mute">
                {new Date(s.played_on).toLocaleDateString(undefined, {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </p>
            </div>
            <div className="flex gap-3 text-sm">
              <button onClick={() => startEdit(s)} className="text-clover hover:text-parchment">
                Edit
              </button>
              <button onClick={() => handleDelete(s.id)} className="text-rose hover:text-parchment">
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
      <p className="text-xs text-mute mt-3">
        Only your latest 5 rounds are kept — adding a new one replaces the
        oldest automatically.
      </p>
    </div>
  );
}
