import Link from "next/link";

const steps = [
  {
    n: "1",
    title: "Subscribe and pick a cause",
    body: "Choose a monthly or yearly plan, then choose the charity your subscription supports. At least 10% of every payment goes straight to them.",
  },
  {
    n: "2",
    title: "Log your rounds",
    body: "Enter your last five Stableford scores as you play them. Your dashboard keeps a rolling record — no spreadsheets required.",
  },
  {
    n: "3",
    title: "Enter the monthly draw",
    body: "Every active subscriber gets a ticket in that month's draw. Match 3, 4 or 5 numbers against the published result to win a share of the pool.",
  },
];

const tiers = [
  { match: "5", label: "Full match", share: "40%", note: "Jackpot — rolls over if unclaimed" },
  { match: "4", label: "Four numbers", share: "35%", note: "Split evenly among winners" },
  { match: "3", label: "Three numbers", share: "25%", note: "Split evenly among winners" },
];

export default function HomePage() {
  return (
    <div>
      {/* HERO */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-24 grid md:grid-cols-[1.1fr_0.9fr] gap-16 items-center">
        <div>
          <h1 className="font-display text-5xl md:text-6xl leading-[1.05]">
            Play your round.
            <br />
            <span className="italic text-clover">Fund the cause.</span>
          </h1>
          <p className="mt-6 text-lg text-mute max-w-md">
            Digital Heroes turns your golf habit into monthly giving and a
            genuine shot at a prize. Log your scores, back a charity, and
            you&apos;re in the draw.
          </p>
          <div className="mt-8 flex items-center gap-4">
            <Link
              href="/signup"
              className="bg-ember text-ink font-medium px-6 py-3 rounded-full hover:brightness-110 transition"
            >
              Subscribe from ₹499/mo
            </Link>
            <Link
              href="#how-it-works"
              className="text-parchment underline decoration-moss underline-offset-4 hover:decoration-parchment transition"
            >
              See how it works
            </Link>
          </div>
        </div>

        <div className="bg-pine border hairline rounded-xl2 p-8">
          <p className="text-sm text-mute mb-4">This month&apos;s draw</p>
          <div className="flex gap-3 mb-6">
            {["07", "14", "22", "31", "44"].map((n, i) => (
              <span
                key={n}
                className="w-12 h-12 rounded-full bg-ink border hairline flex items-center justify-center font-display text-lg"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                {n}
              </span>
            ))}
          </div>
          <p className="text-mute text-sm leading-relaxed">
            Published on the last day of every month, with a live simulation
            run by our admin team beforehand so the pool is always accounted
            for.
          </p>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="max-w-6xl mx-auto px-6 py-20 border-t hairline">
        <h2 className="font-display text-3xl mb-12">How it works</h2>
        <div className="grid md:grid-cols-3 gap-10">
          {steps.map((s, i) => (
            <div key={s.n} className="relative">
              {i < steps.length - 1 && (
                <div className="hidden md:block absolute top-6 left-[calc(100%-1rem)] w-[calc(100%-2rem)] h-px bg-moss" />
              )}
              <div className="w-12 h-12 rounded-full border hairline flex items-center justify-center font-display text-lg text-clover mb-4">
                {s.n}
              </div>
              <h3 className="text-lg font-medium mb-2">{s.title}</h3>
              <p className="text-mute text-sm leading-relaxed">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PRIZE TIERS */}
      <section id="prizes" className="max-w-6xl mx-auto px-6 py-20 border-t hairline">
        <div className="flex flex-col md:flex-row justify-between md:items-end gap-4 mb-10">
          <h2 className="font-display text-3xl">Where the pool goes</h2>
          <p className="text-mute text-sm max-w-sm">
            A fixed share of every subscription funds the prize pool. The
            rest funds your charity and running the platform.
          </p>
        </div>
        <div className="border hairline rounded-xl2 divide-y divide-moss overflow-hidden">
          {tiers.map((t) => (
            <div key={t.match} className="flex items-center gap-6 px-6 py-5 bg-pine">
              <span className="font-display text-2xl text-ember w-10">{t.match}</span>
              <div className="flex-1">
                <p className="font-medium">{t.label}</p>
                <p className="text-mute text-sm">{t.note}</p>
              </div>
              <span className="font-display text-xl">{t.share}</span>
            </div>
          ))}
        </div>
      </section>

      {/* CHARITY SPOTLIGHT */}
      <section className="max-w-6xl mx-auto px-6 py-20 border-t hairline">
        <div className="flex justify-between items-end mb-10">
          <h2 className="font-display text-3xl">Causes you can back</h2>
          <Link href="/charities" className="text-clover hover:text-parchment text-sm">
            View all charities
          </Link>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { name: "Junior Fairways Trust", blurb: "Free coaching and equipment for young golfers from low-income families." },
            { name: "Greenkeepers' Relief Fund", blurb: "Support for course staff and grounds crews facing hardship." },
            { name: "Caddie Scholarship Fund", blurb: "Education grants for caddies and their children." },
          ].map((c) => (
            <div key={c.name} className="bg-pine border hairline rounded-xl2 p-6">
              <div className="w-10 h-10 rounded-full bg-clover/20 border border-clover/40 mb-4" />
              <h3 className="font-medium mb-2">{c.name}</h3>
              <p className="text-mute text-sm leading-relaxed">{c.blurb}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-6 py-24 border-t hairline text-center">
        <h2 className="font-display text-4xl max-w-2xl mx-auto">
          Your next round could fund a cause and win you something back.
        </h2>
        <Link
          href="/signup"
          className="inline-block mt-8 bg-ember text-ink font-medium px-8 py-3 rounded-full hover:brightness-110 transition"
        >
          Get started
        </Link>
      </section>
    </div>
  );
}
