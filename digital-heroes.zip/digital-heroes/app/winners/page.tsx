import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import ProofUpload from "@/components/ProofUpload";

export default async function MyWinningsPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: winners } = await supabase
    .from("winners")
    .select("*, draws(draw_month)")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display text-4xl mb-2">Your winnings</h1>
      <p className="text-mute mb-10">
        Winners must upload a screenshot of their scores from the golf
        platform before a payout is released.
      </p>

      {(!winners || winners.length === 0) && (
        <p className="text-mute">No wins on record yet — good luck in the next draw.</p>
      )}

      <div className="flex flex-col gap-4">
        {(winners ?? []).map((w) => (
          <div key={w.id} className="bg-pine border hairline rounded-xl2 p-6 flex items-center justify-between gap-6">
            <div>
              <p className="font-medium">
                Tier {w.tier} match — {w.draws?.draw_month ? new Date(w.draws.draw_month).toLocaleDateString(undefined, { month: "long", year: "numeric" }) : ""}
              </p>
              <p className="text-mute text-sm">
                ₹{Number(w.amount).toLocaleString(undefined, { maximumFractionDigits: 0 })} · {w.verification_status} · payment {w.payment_status}
              </p>
            </div>
            <ProofUpload winnerId={w.id} userId={user.id} existingUrl={w.proof_url} />
          </div>
        ))}
      </div>
    </div>
  );
}
