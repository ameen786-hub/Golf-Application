"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.push(searchParams.get("redirectTo") || "/dashboard");
    router.refresh();
  }

  return (
    <div className="max-w-md mx-auto px-6 py-24">
      <h1 className="font-display text-3xl mb-2">Sign in</h1>
      <p className="text-mute mb-8">Welcome back.</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="text-sm text-mute block mb-1">Email</label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-pine border hairline rounded-lg px-4 py-2.5 outline-none focus:border-ember"
          />
        </div>
        <div>
          <label className="text-sm text-mute block mb-1">Password</label>
          <input
            required
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-pine border hairline rounded-lg px-4 py-2.5 outline-none focus:border-ember"
          />
        </div>

        {error && <p className="text-rose text-sm">{error}</p>}

        <button
          disabled={loading}
          className="mt-2 bg-ember text-ink font-medium py-2.5 rounded-full hover:brightness-110 transition disabled:opacity-50"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>

      <p className="text-mute text-sm mt-6">
        Need an account?{" "}
        <Link href="/signup" className="text-clover hover:text-parchment">
          Subscribe
        </Link>
      </p>
    </div>
  );
}
