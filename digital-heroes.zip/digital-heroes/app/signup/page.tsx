"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function SignupPage() {
  const supabase = createClient();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });

    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    setCheckEmail(true);
  }

  if (checkEmail) {
    return (
      <div className="max-w-md mx-auto px-6 py-24 text-center">
        <h1 className="font-display text-3xl mb-4">Check your inbox</h1>
        <p className="text-mute">
          We&apos;ve sent a confirmation link to {email}. Confirm your email,
          then sign in and pick your plan.
        </p>
        <Link href="/login" className="text-clover hover:text-parchment mt-6 inline-block">
          Go to sign in
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-6 py-24">
      <h1 className="font-display text-3xl mb-2">Create your account</h1>
      <p className="text-mute mb-8">Start logging rounds and backing a cause.</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="text-sm text-mute block mb-1">Full name</label>
          <input
            required
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full bg-pine border hairline rounded-lg px-4 py-2.5 outline-none focus:border-ember"
          />
        </div>
        <div>
          <label className="text-sm text-mute block mb-1">Email</label>
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-pine border hairline rounded-lg px-4 py-2.5 outline-none focus:border-ember"
          />
        </div>
        <div>
          <label className="text-sm text-mute block mb-1">Password</label>
          <input
            required
            minLength={6}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-pine border hairline rounded-lg px-4 py-2.5 outline-none focus:border-ember"
          />
        </div>

        {error && <p className="text-rose text-sm">{error}</p>}

        <button
          disabled={loading}
          className="mt-2 bg-ember text-ink font-medium py-2.5 rounded-full hover:brightness-110 transition disabled:opacity-50"
        >
          {loading ? "Creating account…" : "Create account"}
        </button>
      </form>

      <p className="text-mute text-sm mt-6">
        Already have an account?{" "}
        <Link href="/login" className="text-clover hover:text-parchment">
          Sign in
        </Link>
      </p>
    </div>
  );
}
