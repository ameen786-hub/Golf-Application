import { NextResponse } from "next/server";
import { createAdminClient, createClient } from "@/lib/supabase/server";
import { algorithmicTicket, randomTicket, matchTier, calculatePayouts } from "@/lib/draw";

// Flat amount (in rupees) that each active subscriber contributes to the
// prize pool per month. In production this would derive from actual Stripe
// payment amounts; a flat figure keeps the sample draw engine simple and
// auditable, and is documented here as a deliberate simplification.
const POOL_CONTRIBUTION_PER_SUBSCRIBER = 150;

export async function POST(req: Request) {
  // Only admins may run or publish a draw.
  const userClient = createClient();
  const {
    data: { user },
  } = await userClient.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: profile } = await userClient.from("profiles").select("role").eq("id", user.id).single();
  if (profile?.role !== "admin") {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }

  const { drawId, action } = await req.json();
  const supabase = createAdminClient();

  const { data: draw } = await supabase.from("draws").select("*").eq("id", drawId).single();
  if (!draw) return NextResponse.json({ error: "Draw not found" }, { status: 404 });

  if (action === "simulate") {
    // 1. Active subscribers
    const { data: activeSubs } = await supabase
      .from("subscriptions")
      .select("user_id")
      .eq("status", "active");
    const userIds = Array.from(new Set((activeSubs ?? []).map((s) => s.user_id)));

    // 2. Generate one ticket per active subscriber
    for (const uid of userIds) {
      let numbers: number[];
      if (draw.draw_type === "algorithmic") {
        const { data: scores } = await supabase
          .from("scores")
          .select("score")
          .eq("user_id", uid)
          .order("played_on", { ascending: false })
          .limit(5);
        numbers = algorithmicTicket((scores ?? []).map((s) => s.score));
      } else {
        numbers = randomTicket();
      }
      await supabase
        .from("tickets")
        .upsert({ draw_id: drawId, user_id: uid, numbers }, { onConflict: "draw_id,user_id" });
    }

    // 3. Draw the winning numbers
    const winningNumbers = randomTicket();
    const poolTotal = userIds.length * POOL_CONTRIBUTION_PER_SUBSCRIBER;

    // 4. Compute tier pools (no rollover applied until we know if tier 5 is claimed)
    const { data: tickets } = await supabase.from("tickets").select("*").eq("draw_id", drawId);
    const winnersByTier: Record<5 | 4 | 3, string[]> = { 5: [], 4: [], 3: [] };
    for (const t of tickets ?? []) {
      const tier = matchTier(t.numbers, winningNumbers);
      if (tier) winnersByTier[tier].push(t.user_id);
    }
    const { pools } = calculatePayouts({
      totalPool: poolTotal,
      jackpotRollover: Number(draw.jackpot_rollover ?? 0),
      winnersByTier,
    });

    await supabase
      .from("draws")
      .update({
        status: "simulated",
        winning_numbers: winningNumbers,
        active_subscribers: userIds.length,
        pool_total: poolTotal,
        tier5_pool: pools.tier5Pool,
        tier4_pool: pools.tier4Pool,
        tier3_pool: pools.tier3Pool,
      })
      .eq("id", drawId);

    return NextResponse.json({ ok: true, winningNumbers, poolTotal });
  }

  if (action === "publish") {
    const { data: tickets } = await supabase.from("tickets").select("*").eq("draw_id", drawId);
    const winnersByTier: Record<5 | 4 | 3, string[]> = { 5: [], 4: [], 3: [] };
    for (const t of tickets ?? []) {
      const tier = matchTier(t.numbers, draw.winning_numbers);
      if (tier) winnersByTier[tier].push(t.user_id);
    }

    const { payouts, nextRollover } = calculatePayouts({
      totalPool: Number(draw.pool_total),
      jackpotRollover: Number(draw.jackpot_rollover ?? 0),
      winnersByTier,
    });

    if (payouts.length > 0) {
      await supabase.from("winners").insert(
        payouts.map((p) => ({
          draw_id: drawId,
          user_id: p.userId,
          tier: p.tier,
          amount: p.amount,
        }))
      );
    }

    await supabase
      .from("draws")
      .update({ status: "published", published_at: new Date().toISOString() })
      .eq("id", drawId);

    return NextResponse.json({ ok: true, payouts, nextRollover });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
