import { createClient } from "@/lib/supabase/server";

export default async function CharitiesPage() {
  const supabase = createClient();
  const { data: charities } = await supabase
    .from("charities")
    .select("*")
    .order("featured", { ascending: false })
    .order("name");

  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="font-display text-4xl mb-2">Causes on Digital Heroes</h1>
      <p className="text-mute mb-12 max-w-lg">
        Every subscriber directs part of their fee to one of these charities.
        Browse who&apos;s here and what they do before you subscribe.
      </p>

      {(!charities || charities.length === 0) && (
        <p className="text-mute">
          No charities have been added yet — check back soon.
        </p>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        {(charities ?? []).map((c) => (
          <div key={c.id} className="bg-pine border hairline rounded-xl2 p-6">
            {c.featured && (
              <span className="inline-block text-xs text-ink bg-ember px-2 py-0.5 rounded-full mb-3">
                Featured
              </span>
            )}
            <h2 className="text-lg font-medium mb-2">{c.name}</h2>
            <p className="text-mute text-sm leading-relaxed mb-4">
              {c.description || "No description added yet."}
            </p>
            {Array.isArray(c.events) && c.events.length > 0 && (
              <div className="border-t hairline pt-3 mt-3">
                <p className="text-xs text-mute mb-2">Upcoming events</p>
                <ul className="text-sm space-y-1">
                  {c.events.map((ev: any, i: number) => (
                    <li key={i} className="text-parchment">
                      {ev.title} — {ev.date}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
