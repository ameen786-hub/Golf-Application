import { createClient } from "@/lib/supabase/server";

export default async function AdminReportsPage() {
  const supabase = createClient();

  const [{ count: totalUsers }, { data: subs }, { data: draws }, { data: winners }] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase.from("subscriptions").select("status, plan"),
    supabase.from("draws").select("*").order("draw_month"),
    supabase.from("winners").select("amount, payment_status"),
  ]);

  const activeCount = (subs ?? []).filter((s) => s.status === "active").length;
  const totalPrizePool = (draws ?? []).reduce((sum, d) => sum + Number(d.pool_total), 0);
  const totalPaidOut = (winners ?? [])
    .filter((w) => w.payment_status === "paid")
    .reduce((sum, w) => sum + Number(w.amount), 0);
  // Charity totals estimated from active subscribers' chosen percentages —
  // see README for how this ties to real Stripe payment amounts.
  const estimatedCharityShare = activeCount * 150 * 0.15; // illustrative default

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Reports</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        {[
          { label: "Total users", value: totalUsers ?? 0 },
          { label: "Active subscribers", value: activeCount },
          { label: "Total prize pool (all draws)", value: `₹${totalPrizePool.toLocaleString()}` },
          { label: "Total paid out", value: `₹${totalPaidOut.toLocaleString()}` },
        ].map((s) => (
          <div key={s.label} className="bg-pine border hairline rounded-xl2 p-5">
            <p className="font-display text-2xl">{s.value}</p>
            <p className="text-mute text-sm mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <h2 className="text-lg font-medium mb-4">Draw statistics</h2>
      <div className="border hairline rounded-xl2 divide-y divide-moss overflow-hidden">
        {(draws ?? []).map((d) => (
          <div key={d.id} className="px-5 py-3 flex justify-between text-sm bg-pine">
            <span>{new Date(d.draw_month).toLocaleDateString(undefined, { month: "long", year: "numeric" })}</span>
            <span className="text-mute">
              {d.status} · pool ₹{Number(d.pool_total).toLocaleString()} · {d.active_subscribers} subscribers
            </span>
          </div>
        ))}
        {(!draws || draws.length === 0) && <p className="px-5 py-6 text-mute text-sm">No draws yet.</p>}
      </div>
    </div>
  );
}
