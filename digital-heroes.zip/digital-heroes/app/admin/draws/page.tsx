import { createClient, createAdminClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

async function createDraw(formData: FormData) {
  "use server";
  const month = formData.get("month") as string; // yyyy-mm
  const drawType = formData.get("drawType") as string;
  const rollover = Number(formData.get("rollover") || 0);
  const supabase = createAdminClient();
  await supabase.from("draws").insert({
    draw_month: `${month}-01`,
    draw_type: drawType,
    jackpot_rollover: rollover,
    status: "draft",
  });
  revalidatePath("/admin/draws");
}

export default async function AdminDrawsPage() {
  const supabase = createClient();
  const { data: draws } = await supabase
    .from("draws")
    .select("*")
    .order("draw_month", { ascending: false });

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Draws</h1>

      <form action={createDraw} className="bg-pine border hairline rounded-xl2 p-6 mb-8 flex flex-wrap items-end gap-4">
        <div>
          <label className="text-xs text-mute block mb-1">Draw month</label>
          <input type="month" name="month" required className="bg-ink border hairline rounded-lg px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="text-xs text-mute block mb-1">Draw type</label>
          <select name="drawType" className="bg-ink border hairline rounded-lg px-3 py-2 text-sm">
            <option value="random">Random</option>
            <option value="algorithmic">Algorithmic (score-weighted)</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-mute block mb-1">Jackpot rollover in (₹)</label>
          <input type="number" name="rollover" defaultValue={0} min={0} className="bg-ink border hairline rounded-lg px-3 py-2 text-sm w-32" />
        </div>
        <button className="bg-ember text-ink text-sm font-medium px-5 py-2 rounded-full hover:brightness-110 transition">
          Create draw
        </button>
      </form>
      <p className="text-xs text-mute mb-8 -mt-4">
        Rollover carries the unclaimed 5-match jackpot from the previous
        month. Check last month&apos;s draw below before entering it.
      </p>

      <div className="flex flex-col gap-4">
        {(draws ?? []).map((d) => (
          <div key={d.id} className="bg-pine border hairline rounded-xl2 p-6">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="font-medium">
                  {new Date(d.draw_month).toLocaleDateString(undefined, { month: "long", year: "numeric" })}
                </p>
                <p className="text-xs text-mute">
                  {d.draw_type} · {d.status}
                  {d.status !== "draft" && ` · winning numbers: ${d.winning_numbers.join(", ")}`}
                </p>
              </div>
              <DrawActions id={d.id} status={d.status} />
            </div>
            {d.status !== "draft" && (
              <div className="grid grid-cols-3 gap-4 text-sm border-t hairline pt-3 mt-3">
                <div>
                  <p className="text-mute text-xs">Pool total</p>
                  <p>₹{Number(d.pool_total).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-mute text-xs">Active subscribers</p>
                  <p>{d.active_subscribers}</p>
                </div>
                <div>
                  <p className="text-mute text-xs">Tier 5 / 4 / 3 pool</p>
                  <p>
                    ₹{Number(d.tier5_pool).toLocaleString()} / ₹{Number(d.tier4_pool).toLocaleString()} / ₹{Number(d.tier3_pool).toLocaleString()}
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
        {(!draws || draws.length === 0) && <p className="text-mute text-sm">No draws created yet.</p>}
      </div>
    </div>
  );
}

function DrawActions({ id, status }: { id: string; status: string }) {
  return (
    <div className="flex gap-3 text-sm">
      {status === "draft" && <RunButton id={id} action="simulate" label="Run simulation" />}
      {status === "simulated" && <RunButton id={id} action="publish" label="Publish result" />}
    </div>
  );
}

function RunButton({ id, action, label }: { id: string; action: string; label: string }) {
  async function run() {
    "use server";
    const base = process.env.NEXT_PUBLIC_SITE_URL || "";
    await fetch(`${base}/api/draws/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ drawId: id, action }),
      cache: "no-store",
    });
    revalidatePath("/admin/draws");
  }
  return (
    <form action={run}>
      <button className="text-clover hover:text-parchment">{label}</button>
    </form>
  );
}
