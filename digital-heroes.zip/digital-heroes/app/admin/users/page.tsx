import { createClient, createAdminClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

async function toggleAdmin(formData: FormData) {
  "use server";
  const id = formData.get("id") as string;
  const nextRole = formData.get("nextRole") as string;
  const supabase = createAdminClient();
  await supabase.from("profiles").update({ role: nextRole }).eq("id", id);
  revalidatePath("/admin/users");
}

export default async function AdminUsersPage() {
  const supabase = createClient();
  const { data: profiles } = await supabase
    .from("profiles")
    .select("*, subscriptions(status, plan)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Users</h1>
      <div className="border hairline rounded-xl2 divide-y divide-moss overflow-hidden">
        {(profiles ?? []).map((p: any) => (
          <div key={p.id} className="flex items-center justify-between gap-4 px-5 py-4 bg-pine">
            <div>
              <p className="font-medium">{p.full_name || "Unnamed"}</p>
              <p className="text-xs text-mute">
                {p.role} · {p.subscriptions?.[0]?.status ?? "no subscription"}
              </p>
            </div>
            <form action={toggleAdmin}>
              <input type="hidden" name="id" value={p.id} />
              <input type="hidden" name="nextRole" value={p.role === "admin" ? "subscriber" : "admin"} />
              <button className="text-sm text-clover hover:text-parchment">
                {p.role === "admin" ? "Revoke admin" : "Make admin"}
              </button>
            </form>
          </div>
        ))}
        {(!profiles || profiles.length === 0) && (
          <p className="px-5 py-6 text-mute text-sm">No users yet.</p>
        )}
      </div>
    </div>
  );
}
