import { createClient } from "@/lib/supabase/server";

export default async function AdminOverviewPage() {
  const supabase = createClient();

  const [{ count: userCount }, { count: activeSubs }, { data: draws }, { data: charities }] =
    await Promise.all([
      supabase.from("profiles").select("*", { count: "exact", head: true }),
      supabase.from("subscriptions").select("*", { count: "exact", head: true }).eq("status", "active"),
      supabase.from("draws").select("*").order("draw_month", { ascending: false }).limit(1),
      supabase.from("charities").select("*", { count: "exact", head: true }),
    ]);

  const latestDraw = draws?.[0];

  const stats = [
    { label: "Total users", value: userCount ?? 0 },
    { label: "Active subscribers", value: activeSubs ?? 0 },
    { label: "Charities listed", value: charities ?? 0 },
    {
      label: "Latest pool total",
      value: latestDraw ? `₹${Number(latestDraw.pool_total).toLocaleString()}` : "—",
    },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Overview</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="bg-pine border hairline rounded-xl2 p-5">
            <p className="font-display text-2xl">{s.value as any}</p>
            <p className="text-mute text-sm mt-1">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
