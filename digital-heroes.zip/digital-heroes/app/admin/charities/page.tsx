import { createClient, createAdminClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

async function addCharity(formData: FormData) {
  "use server";
  const supabase = createAdminClient();
  await supabase.from("charities").insert({
    name: formData.get("name") as string,
    description: formData.get("description") as string,
    featured: formData.get("featured") === "on",
  });
  revalidatePath("/admin/charities");
}

async function deleteCharity(formData: FormData) {
  "use server";
  const id = formData.get("id") as string;
  const supabase = createAdminClient();
  await supabase.from("charities").delete().eq("id", id);
  revalidatePath("/admin/charities");
}

async function toggleFeatured(formData: FormData) {
  "use server";
  const id = formData.get("id") as string;
  const next = formData.get("next") === "true";
  const supabase = createAdminClient();
  await supabase.from("charities").update({ featured: next }).eq("id", id);
  revalidatePath("/admin/charities");
}

export default async function AdminCharitiesPage() {
  const supabase = createClient();
  const { data: charities } = await supabase.from("charities").select("*").order("name");

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Charities</h1>

      <form action={addCharity} className="bg-pine border hairline rounded-xl2 p-6 mb-8 flex flex-col gap-3">
        <h2 className="font-medium mb-1">Add a charity</h2>
        <input
          name="name"
          required
          placeholder="Charity name"
          className="bg-ink border hairline rounded-lg px-3 py-2 text-sm outline-none focus:border-ember"
        />
        <textarea
          name="description"
          placeholder="Short description"
          className="bg-ink border hairline rounded-lg px-3 py-2 text-sm outline-none focus:border-ember"
        />
        <label className="flex items-center gap-2 text-sm text-mute">
          <input type="checkbox" name="featured" /> Feature on homepage
        </label>
        <button className="self-start bg-ember text-ink text-sm font-medium px-5 py-2 rounded-full hover:brightness-110 transition">
          Add charity
        </button>
      </form>

      <div className="border hairline rounded-xl2 divide-y divide-moss overflow-hidden">
        {(charities ?? []).map((c) => (
          <div key={c.id} className="flex items-center justify-between gap-4 px-5 py-4 bg-pine">
            <div>
              <p className="font-medium">{c.name}</p>
              <p className="text-xs text-mute">{c.featured ? "Featured" : "Not featured"}</p>
            </div>
            <div className="flex gap-4 text-sm">
              <form action={toggleFeatured}>
                <input type="hidden" name="id" value={c.id} />
                <input type="hidden" name="next" value={(!c.featured).toString()} />
                <button className="text-clover hover:text-parchment">
                  {c.featured ? "Unfeature" : "Feature"}
                </button>
              </form>
              <form action={deleteCharity}>
                <input type="hidden" name="id" value={c.id} />
                <button className="text-rose hover:text-parchment">Delete</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
