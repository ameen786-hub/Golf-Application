import { createClient, createAdminClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

async function setVerification(formData: FormData) {
  "use server";
  const id = formData.get("id") as string;
  const status = formData.get("status") as string;
  const supabase = createAdminClient();
  await supabase.from("winners").update({ verification_status: status }).eq("id", id);
  revalidatePath("/admin/winners");
}

async function markPaid(formData: FormData) {
  "use server";
  const id = formData.get("id") as string;
  const supabase = createAdminClient();
  await supabase.from("winners").update({ payment_status: "paid" }).eq("id", id);
  revalidatePath("/admin/winners");
}

export default async function AdminWinnersPage() {
  const supabase = createClient();
  const { data: winners } = await supabase
    .from("winners")
    .select("*, profiles(full_name), draws(draw_month)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Winners</h1>
      <div className="border hairline rounded-xl2 divide-y divide-moss overflow-hidden">
        {(winners ?? []).map((w: any) => (
          <div key={w.id} className="px-5 py-4 bg-pine flex items-center justify-between gap-4 flex-wrap">
            <div>
              <p className="font-medium">
                {w.profiles?.full_name || "Unnamed"} — Tier {w.tier} — ₹{Number(w.amount).toLocaleString()}
              </p>
              <p className="text-xs text-mute">
                {w.draws?.draw_month && new Date(w.draws.draw_month).toLocaleDateString(undefined, { month: "long", year: "numeric" })}
                {" · "}
                {w.proof_url ? "Proof uploaded" : "No proof yet"} · {w.verification_status} · {w.payment_status}
              </p>
            </div>
            <div className="flex gap-3 text-sm">
              <form action={setVerification}>
                <input type="hidden" name="id" value={w.id} />
                <input type="hidden" name="status" value="approved" />
                <button className="text-clover hover:text-parchment">Approve</button>
              </form>
              <form action={setVerification}>
                <input type="hidden" name="id" value={w.id} />
                <input type="hidden" name="status" value="rejected" />
                <button className="text-rose hover:text-parchment">Reject</button>
              </form>
              {w.verification_status === "approved" && w.payment_status !== "paid" && (
                <form action={markPaid}>
                  <input type="hidden" name="id" value={w.id} />
                  <button className="text-ember hover:text-parchment">Mark paid</button>
                </form>
              )}
            </div>
          </div>
        ))}
        {(!winners || winners.length === 0) && <p className="px-5 py-6 text-mute text-sm">No winners yet.</p>}
      </div>
    </div>
  );
}
