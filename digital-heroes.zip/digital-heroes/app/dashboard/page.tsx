import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import ScoreEntryForm from "@/components/ScoreEntryForm";
import CharitySelector from "@/components/CharitySelector";
import Link from "next/link";

export default async function DashboardPage() {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const [{ data: profile }, { data: subscription }, { data: scores }, { data: charities }, { data: tickets }, { data: winners }, { data: upcomingDraw }] =
    await Promise.all([
      supabase.from("profiles").select("*").eq("id", user.id).single(),
      supabase
        .from("subscriptions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabase
        .from("scores")
        .select("*")
        .eq("user_id", user.id)
        .order("played_on", { ascending: false }),
      supabase.from("charities").select("id, name").order("name"),
      supabase.from("tickets").select("*, draws(draw_month, status)").eq("user_id", user.id),
      supabase.from("winners").select("*, draws(draw_month)").eq("user_id", user.id).order("created_at", { ascending: false }),
      supabase.from("draws").select("*").eq("status", "draft").order("draw_month", { ascending: false }).limit(1).maybeSingle(),
    ]);

  const isActive = subscription?.status === "active";
  const totalWon = (winners ?? []).reduce((sum, w) => sum + Number(w.amount), 0);

  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="font-display text-4xl mb-1">Your dashboard</h1>
      <p className="text-mute mb-12">
        Welcome back{profile?.full_name ? `, ${profile.full_name}` : ""}.
      </p>

      <div className="grid md:grid-cols-2 gap-6 mb-6">
        {/* Subscription status */}
        <section className="bg-pine border hairline rounded-xl2 p-6">
          <h2 className="text-lg font-medium mb-4">Subscription</h2>
          {subscription ? (
            <>
              <p className="text-mute text-sm mb-1">
                Status:{" "}
                <span className={isActive ? "text-clover" : "text-rose"}>
                  {subscription.status}
                </span>
              </p>
              <p className="text-mute text-sm mb-1">Plan: {subscription.plan}</p>
              {subscription.current_period_end && (
                <p className="text-mute text-sm">
                  Renews:{" "}
                  {new Date(subscription.current_period_end).toLocaleDateString()}
                </p>
              )}
            </>
          ) : (
            <>
              <p className="text-mute text-sm mb-4">
                You don&apos;t have an active subscription yet.
              </p>
              <Link
                href="/dashboard/subscribe"
                className="inline-block bg-ember text-ink text-sm font-medium px-5 py-2 rounded-full hover:brightness-110 transition"
              >
                Choose a plan
              </Link>
            </>
          )}
        </section>

        {/* Winnings */}
        <section className="bg-pine border hairline rounded-xl2 p-6">
          <h2 className="text-lg font-medium mb-4">Winnings</h2>
          <p className="font-display text-3xl text-ember mb-1">
            ₹{totalWon.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </p>
          <p className="text-mute text-sm mb-4">Total won to date</p>
          {(winners ?? []).length === 0 ? (
            <p className="text-mute text-sm">No wins yet — every entry counts.</p>
          ) : (
            <ul className="text-sm space-y-1">
              {winners!.slice(0, 3).map((w) => (
                <li key={w.id} className="flex justify-between text-mute">
                  <span>Tier {w.tier} match</span>
                  <span className={w.payment_status === "paid" ? "text-clover" : "text-mute"}>
                    {w.payment_status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Participation */}
      <section className="bg-pine border hairline rounded-xl2 p-6 mb-6">
        <h2 className="text-lg font-medium mb-4">Participation</h2>
        <div className="flex gap-8 flex-wrap">
          <div>
            <p className="font-display text-2xl">{(tickets ?? []).length}</p>
            <p className="text-mute text-sm">Draws entered</p>
          </div>
          <div>
            <p className="font-display text-2xl">
              {upcomingDraw ? new Date(upcomingDraw.draw_month).toLocaleDateString(undefined, { month: "long", year: "numeric" }) : "—"}
            </p>
            <p className="text-mute text-sm">Next draw</p>
          </div>
        </div>
      </section>

      {/* Charity */}
      <section className="bg-pine border hairline rounded-xl2 p-6 mb-6">
        <h2 className="text-lg font-medium mb-4">Your charity</h2>
        <CharitySelector
          userId={user.id}
          charities={charities ?? []}
          currentCharityId={profile?.charity_id ?? null}
          currentPercentage={profile?.charity_percentage ?? 10}
        />
      </section>

      {/* Scores */}
      <section className="bg-pine border hairline rounded-xl2 p-6">
        <h2 className="text-lg font-medium mb-4">Your rounds</h2>
        <ScoreEntryForm userId={user.id} scores={scores ?? []} />
      </section>
    </div>
  );
}
