"use client";

import { useState } from "react";

export default function SubscribePage() {
  const [loading, setLoading] = useState<"monthly" | "yearly" | null>(null);

  async function subscribe(plan: "monthly" | "yearly") {
    setLoading(plan);
    const res = await fetch("/api/stripe/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan }),
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
    else setLoading(null);
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display text-4xl mb-2">Choose your plan</h1>
      <p className="text-mute mb-10">
        Every plan gives you full access, a ticket in the monthly draw, and
        funds the charity you choose.
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-pine border hairline rounded-xl2 p-8">
          <p className="text-mute text-sm mb-1">Monthly</p>
          <p className="font-display text-4xl mb-6">₹499</p>
          <button
            onClick={() => subscribe("monthly")}
            disabled={loading !== null}
            className="w-full bg-ember text-ink font-medium py-2.5 rounded-full hover:brightness-110 transition disabled:opacity-50"
          >
            {loading === "monthly" ? "Redirecting…" : "Subscribe monthly"}
          </button>
        </div>
        <div className="bg-pine border-2 border-clover rounded-xl2 p-8 relative">
          <span className="absolute -top-3 right-6 bg-clover text-ink text-xs font-medium px-3 py-1 rounded-full">
            Best value
          </span>
          <p className="text-mute text-sm mb-1">Yearly</p>
          <p className="font-display text-4xl mb-6">₹4,999</p>
          <button
            onClick={() => subscribe("yearly")}
            disabled={loading !== null}
            className="w-full bg-clover text-ink font-medium py-2.5 rounded-full hover:brightness-110 transition disabled:opacity-50"
          >
            {loading === "yearly" ? "Redirecting…" : "Subscribe yearly"}
          </button>
        </div>
      </div>
    </div>
  );
}
