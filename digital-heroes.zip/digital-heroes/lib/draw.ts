/**
 * Digital Heroes — draw engine
 * ------------------------------------------------------------------
 * Numbers are drawn from a 1–49 pool, 5 numbers per ticket/draw, no
 * repeats within a ticket or within the winning set.
 *
 * Two ticket-generation modes:
 *  - "random": uniformly random 5 numbers per subscriber.
 *  - "algorithmic": weighted by the subscriber's recent Stableford score
 *    frequency, so numbers tied to a golfer's more common score bands
 *    come up more often (a light "skill flavour" on top of the game of
 *    chance, per the PRD's "algorithm-powered" draw type).
 *
 * Matching: compare each ticket's 5 numbers against the winning 5 and
 * bucket the subscriber into the 5/4/3-number match tier (best tier
 * wins; there's no "at least 3" double counting).
 */

export const POOL_MIN = 1;
export const POOL_MAX = 49;
export const NUMBERS_PER_TICKET = 5;

export function randomTicket(): number[] {
  const pool = Array.from(
    { length: POOL_MAX - POOL_MIN + 1 },
    (_, i) => i + POOL_MIN
  );
  const picked: number[] = [];
  for (let i = 0; i < NUMBERS_PER_TICKET; i++) {
    const idx = Math.floor(Math.random() * pool.length);
    picked.push(pool.splice(idx, 1)[0]);
  }
  return picked.sort((a, b) => a - b);
}

/**
 * Builds a weighted pool from a user's last five Stableford scores
 * (1–45), then draws 5 unique numbers from it. Scores that repeat more
 * often get proportionally more "tickets" in the weighted pool; the
 * full 1–49 range is always included at low weight so every number
 * stays reachable.
 */
export function algorithmicTicket(recentScores: number[]): number[] {
  const weight = new Map<number, number>();
  for (let n = POOL_MIN; n <= POOL_MAX; n++) weight.set(n, 1); // base weight
  for (const s of recentScores) {
    const n = Math.min(POOL_MAX, Math.max(POOL_MIN, s));
    weight.set(n, (weight.get(n) ?? 1) + 3);
  }

  const bag: number[] = [];
  for (const [n, w] of weight) for (let i = 0; i < w; i++) bag.push(n);

  const picked = new Set<number>();
  while (picked.size < NUMBERS_PER_TICKET) {
    const n = bag[Math.floor(Math.random() * bag.length)];
    picked.add(n);
  }
  return Array.from(picked).sort((a, b) => a - b);
}

export function matchTier(
  ticket: number[],
  winning: number[]
): 5 | 4 | 3 | null {
  const winSet = new Set(winning);
  const matches = ticket.filter((n) => winSet.has(n)).length;
  if (matches >= 5) return 5;
  if (matches === 4) return 4;
  if (matches === 3) return 3;
  return null;
}

/** Pool share per PRD §07. */
export const POOL_SHARE: Record<5 | 4 | 3, number> = {
  5: 0.4,
  4: 0.35,
  3: 0.25,
};

/**
 * Splits each tier's pool equally among that tier's winners. Tier 5 is
 * a jackpot: if nobody hits 5, the tier-5 pool rolls into next month's
 * jackpot rather than being paid out.
 */
export function calculatePayouts(params: {
  totalPool: number;
  jackpotRollover: number;
  winnersByTier: Record<5 | 4 | 3, string[]>; // user ids
}) {
  const { totalPool, jackpotRollover, winnersByTier } = params;

  const tier5Pool = totalPool * POOL_SHARE[5] + jackpotRollover;
  const tier4Pool = totalPool * POOL_SHARE[4];
  const tier3Pool = totalPool * POOL_SHARE[3];

  const payouts: { userId: string; tier: 5 | 4 | 3; amount: number }[] = [];
  let nextRollover = 0;

  if (winnersByTier[5].length > 0) {
    const each = tier5Pool / winnersByTier[5].length;
    winnersByTier[5].forEach((userId) => payouts.push({ userId, tier: 5, amount: each }));
  } else {
    nextRollover = tier5Pool; // jackpot rolls over, unclaimed
  }

  if (winnersByTier[4].length > 0) {
    const each = tier4Pool / winnersByTier[4].length;
    winnersByTier[4].forEach((userId) => payouts.push({ userId, tier: 4, amount: each }));
  }

  if (winnersByTier[3].length > 0) {
    const each = tier3Pool / winnersByTier[3].length;
    winnersByTier[3].forEach((userId) => payouts.push({ userId, tier: 3, amount: each }));
  }

  return {
    payouts,
    pools: { tier5Pool, tier4Pool, tier3Pool },
    nextRollover,
  };
}
